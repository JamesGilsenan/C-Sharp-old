using System;

namespace ConsoleGame
{
  class Game : SuperGame
  {
    
  }
}